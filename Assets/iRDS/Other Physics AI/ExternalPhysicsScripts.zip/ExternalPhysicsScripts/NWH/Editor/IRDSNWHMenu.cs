﻿using UnityEngine;
using UnityEditor;
using NWH.VehiclePhysics;

public class IRDSNWHMenu : Editor {

	[MenuItem("GameObject/iRDS/Vehicle/NWH Vehicle Physics/Add AI Controller Scripts to Selected Car")]
	static void AddExampleCar () {
		GameObject obj = Selection.activeGameObject;
		bool destroy = false;
		if (obj.GetComponent<IRDSCarControllerAI>())
			EditorUtility.DisplayDialog("Message", "This car has the scripts already!","Ok");
		else
		{
			if( PrefabUtility.GetPrefabType(obj) == PrefabType.Prefab)
			{
				obj = PrefabUtility.InstantiatePrefab(obj) as GameObject;
				destroy = true;
			}
			obj.AddComponent<IRDSCarControllerAI>();
			obj.GetComponent<IRDSCarControllerAI>().isExternalCarPhysics = true;
			obj.AddComponent<IRDSCarControllInputNWH>();
            IRDSCarControllInputNWH nhwCar = obj.GetComponent<IRDSCarControllInputNWH>();
			nhwCar.drivetrain = obj.GetComponent<VehicleController>();
			nhwCar.carInputs = obj.GetComponent<IRDSCarControllInput>();
			nhwCar.carAI = obj.GetComponent<IRDSCarControllerAI>();
			GameObject cameraViews = PrefabUtility.InstantiatePrefab(Resources.Load("AISystem/CameraViews") as GameObject) as GameObject;
			if (cameraViews !=null){
				cameraViews.transform.parent = obj.transform;
				cameraViews.transform.localPosition = Vector3.zero;
				cameraViews.transform.localScale = Vector3.one;
				cameraViews.transform.localRotation = Quaternion.Euler(Vector3.zero);
			}else
			{
				EditorUtility.DisplayDialog("Important Message!","You are using and older version of iRDS or a prefab required is missing, please upgrade to the latest version or re-import the package, thanks!","Ok");
			}
			EditorUtility.DisplayDialog("Important Message!","You are almost done, please go to your prefab that is located at iRDS/Resources/Cars/"+obj.name+".prefab and" +
			                            " add to the script IRDSCarControllInputNWH on the array Front Wheels the 2 front wheels objects, this is required for the AI to work, thanks!","Ok");
			CreatePrefab(obj,destroy);
		}
	}
	
	static void CreatePrefab(GameObject obj, bool destroy)
	{
		string Path1 = "Assets/iRDS/Resources/Cars/";
		string name = obj.name;
		string localPath = Path1 + name + ".prefab";
		if (AssetDatabase.LoadAssetAtPath(localPath, typeof(GameObject)))
		{
			if (EditorUtility.DisplayDialog("Are you sure?", "The prefab already exists. Do you want to overwrite it?", "Yes", "No"))
			{
				createNew(obj, localPath, destroy);
			}
		}
		else
		{
			createNew(obj, localPath, destroy);
		}
		
	}
	
	static void createNew(GameObject obj, string localPath, bool destroy)
	{
		Object prefab = PrefabUtility.CreatePrefab (localPath, obj);
		PrefabUtility.ReplacePrefab(obj, prefab, ReplacePrefabOptions.ConnectToPrefab);
		AssetDatabase.Refresh();
		if (destroy)
			DestroyImmediate(obj);
	}
}
