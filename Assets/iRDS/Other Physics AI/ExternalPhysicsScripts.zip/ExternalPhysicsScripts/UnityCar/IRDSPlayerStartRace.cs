using UnityEngine;
using System.Collections.Generic;

public class IRDSPlayerStartRace : MonoBehaviour
{

    Drivetrain drivetrain;
    // Use this for initialization

    IRDSCarControllInput carInputs;
    IRDSCarControllerAI aiInputs;
    CarDynamics carDynamics;
    IRDSUnityCarAIController unityCarController;
    public CarDynamics.Controller originalControl;

    private bool autoClutch;
    private bool automatic;
    //	private bool smoothinput;
    private float originalDrag;
    private AerodynamicResistance drag;

    bool doItOnce = false;
    Wheel[] wheels;
    private float getFrictionTime = 0;

    float[] friction = new float[2];



    public void Awake()
    {
        carDynamics = GetComponent<CarDynamics>();

        drag = GetComponent<AerodynamicResistance>();
        originalDrag = drag.Cx;
        aiInputs = GetComponent<IRDSCarControllerAI>();
        carInputs = GetComponent<IRDSCarControllInput>();
        wheels = GetComponentsInChildren<Wheel>();
        drivetrain = GetComponent<Drivetrain>();
        aiInputs.isExternalCarPhysics = true;
        //		aiInputs.wheelRadius = wheels[0].radius;
        RunOnce();
        unityCarController = GetComponent<IRDSUnityCarAIController>();
    }


    void Start()
    {
        if (carInputs.GetCarPilot() && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
        {
            carDynamics.controller = originalControl;
            switch (carDynamics.controller)
            {
                case CarDynamics.Controller.axis:
                    GetComponent<AxisCarController>().enabled = true;
                    break;
                case CarDynamics.Controller.mouse:
                    GetComponent<MouseCarController>().enabled = true;
                    break;
                case CarDynamics.Controller.mobile:
                    GetComponent<MobileCarController>().enabled = true;
                    break;
                case CarDynamics.Controller.external:
                    unityCarController.enabled = true;
                    break;
            }
            unityCarController.enabled = false;
            automatic = drivetrain.automatic;
            autoClutch = drivetrain.autoClutch;

        }
        else if (!carInputs.GetCarPilot() || carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
        {
            CarController[] controls = GetComponents<CarController>();
            foreach (CarController control in controls)
                if (control.GetInstanceID() != unityCarController.GetInstanceID()) Destroy(control);
            carDynamics.controller = CarDynamics.Controller.external;
            if (!carInputs.auto2)
                unityCarController.smoothInput = false;
            drivetrain.automatic = false;
            drivetrain.autoClutch = true;

        }
        carInputs.gearRatiosLengthExternalPhysics = drivetrain.gearRatios.Length;
        carInputs.maxRpmExternalPhysics = drivetrain.maxRPM;
        List<Transform> frontWheels = new List<Transform>();
        foreach (Wheel wheel in wheels)
        {
            if (wheel.wheelPos == WheelPos.FRONT_LEFT || wheel.wheelPos == WheelPos.FRONT_RIGHT)
                frontWheels.Add(wheel.transform);
        }
        aiInputs.SetIRDSWheelsCenter(frontWheels.ToArray());
        carInputs.gearSpeedsExternalCarPhysics = new float[drivetrain.gearRatios.Length];
        for (int i = 0; i < drivetrain.gearRatios.Length; i++)
            carInputs.gearSpeedsExternalCarPhysics[i] = ((drivetrain.maxRPM / (drivetrain.finalDriveRatio * drivetrain.gearRatios[i]) * drivetrain.poweredWheels[0].radius * 2.0f * Mathf.PI * 60.0f / 1000.0f) / 3.6f) * 0.9f;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (carInputs.GetCarPilot())
        {
            if (!IRDSStatistics.GetCanRace() && !aiInputs.rollingStart)
                drivetrain.gear = 1;
            if (aiInputs.NavigateTWaypoints.GoPits)
            {
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                    drag.Cx = 100;
                else drag.Cx = originalDrag;
            }
            else if (drag.Cx != originalDrag) drag.Cx = originalDrag;
            if (carDynamics.controller != originalControl && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                carDynamics.controller = originalControl;

                //				switch(carDynamics.controller)
                //				{
                //				case CarDynamics.Controller.axis:
                //					GetComponent<AxisCarController>().enabled = true;
                //					break;
                //				case CarDynamics.Controller.mouse:
                //					GetComponent<MouseCarController>().enabled = true;
                //					break;
                //				case CarDynamics.Controller.mobile:
                //					GetComponent<MobileCarController>().enabled = true;
                //					break;
                //				case CarDynamics.Controller.external:
                //					unityCarController.enabled = true;
                //					break;
                //			}

                drivetrain.automatic = automatic;
                drivetrain.autoClutch = autoClutch;
            }
            else if (carDynamics.controller != CarDynamics.Controller.external && (carInputs.auto1 || carInputs.auto2 || carInputs.auto3))
            {
                CarController[] controls = GetComponents<CarController>();
                foreach (CarController control in controls)
                    if (control.GetInstanceID() != unityCarController.GetInstanceID()) Destroy(control);
                carDynamics.controller = CarDynamics.Controller.external;
                unityCarController.enabled = true;
                carInputs.setHandBrakeInput(0);
            }


        }
        else
        {
            if (carDynamics.controller != CarDynamics.Controller.external)
            {
                carDynamics.controller = CarDynamics.Controller.external;
                unityCarController.enabled = true;
                drivetrain.autoClutch = true;
                drivetrain.automatic = false;
                unityCarController.smoothInput = false;
                carInputs.setHandBrakeInput(0);
            }
        }
        getFriction();
        carInputs.rpmExternalPhysics = drivetrain.rpm;
    }



    void getFriction()
    {
        float minFriction = float.MaxValue;

        float tyreW = float.MaxValue;
        float kFriction = 0;
        bool tireSlipAngle = false;
        float tyreWear = 0f;

        foreach (Wheel w in wheels)
        {
            aiInputs.SetTireSlipAngleExternalPhysics((Mathf.Abs(w.slipVelo) * 0.05f - 0.7f > 0 && carInputs.GetThrottleInput() > 0) ? true : tireSlipAngle);
            if (!doItOnce)
            {
                if (Time.time - getFrictionTime > 3)
                    doItOnce = true;
                float Fz = (1f / wheels.Length) * GetComponent<Rigidbody>().mass * -Physics.gravity.y * 0.001f;
                float materialFriction = 1f;
                if (w.hitDown.collider != null)
                {
                    foreach (MyPhysicMaterial mat in carDynamics.physicMaterials)
                    {
                        if (w.hitDown.collider != null && mat.physicMaterial != null && w.hitDown.collider.material.name == mat.physicMaterial.name)
                            materialFriction = mat.grip;
                        else materialFriction = 1f;
                    }
                }

                float uP1 = w.a[1] * Fz + w.a[2];
                float D1 = uP1 * Fz * materialFriction;
                kFriction = D1 / (Fz * 1000f);
                if (kFriction < minFriction && kFriction != 0)
                {
                    minFriction = kFriction;
                }
            }
            else
            {
                if (w.normalForce != 0)
                    kFriction = w.maxFx / w.normalForce;
                else
                {
                    float Fz = (1f / wheels.Length) * GetComponent<Rigidbody>().mass * -Physics.gravity.y * 0.001f;
                    float materialFriction = 1f;
                    float uP1 = w.a[1] * Fz + w.a[2];
                    float D1 = uP1 * Fz * materialFriction;
                    kFriction = D1 / (Fz * 1000f);
                }
                if (kFriction < minFriction && kFriction != 0)
                    minFriction = kFriction;
            }
            tyreWear = w.b[2];
            if (tyreWear < tyreW)
                tyreW = tyreWear;
        }
        if (minFriction != float.MaxValue && minFriction != 0)
        {
            friction[0] = minFriction;
            friction[1] = minFriction;
            aiInputs.SetFrictionExtaernalPhysics(friction);
        }
        aiInputs.SetTyreWearExternalPhysics((tyreW));
    }

    void GetMaxSteerLock()
    {
        float maxSteerLock = 0f;
        foreach (Wheel wheel in wheels)
            maxSteerLock = (wheel.maxSteeringAngle != 0 && wheel.maxSteeringAngle > maxSteerLock) ? Mathf.Abs(wheel.maxSteeringAngle) : maxSteerLock;
        aiInputs.SetMaxSteerLockExternalPhysics(Mathf.Abs(maxSteerLock));
    }

    void RunOnce()
    {

        carInputs.SetTopSpeedExternalPhysics(drivetrain.maxRPM / (drivetrain.finalDriveRatio * drivetrain.gearRatios[drivetrain.gearRatios.Length - 1]) * wheels[0].radius * 2.0f * Mathf.PI * 60.0f / 1000.0f);
        carInputs.maxRpmExternalPhysics = (drivetrain.maxRPM);
        carInputs.gearRatiosLengthExternalPhysics = (drivetrain.gearRatios.Length);
        GetMaxSteerLock();
        aiInputs.SetWingaFactorExternalPhysics(GetComponent<Wing>() ? GetComponent<Wing>().dragCoefficient : 0);
        float cl = 0;
        foreach (Wing wing in GetComponentsInChildren<Wing>())
            cl += wing.dragCoefficient;
        aiInputs.SetClFactorExternalPhysics(cl);
        float h = 0;
        foreach (Wheel w in wheels)
            h += w.suspensionTravel;
        aiInputs.SetHFactorExternalPhysics(h);
        aiInputs.SetCWFactorExternalPhysics(drag.Cx);
        getFriction();
        getFrictionTime = Time.time;
    }

}
