using System;
using UnityEngine;

public class IRDSCarControllInputRCC : MonoBehaviour
{

    // cached reference for CarControl
    public RCC_CarControllerV3 drivetrain;
    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    private float airDrag;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<RCC_CarControllerV3>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
        IRDSStatistics.onRaceRestarted += OnRaceStarted;
    }
    void Start()
    {

        if (carInputs.GetCarPilot() && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
        {
            drivetrain.externalController = false;
        }
        else
        {
            drivetrain.externalController = true;
        }

        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];
    }


    private void OnDestroy()
    {
        IRDSStatistics.onRaceRestarted -= OnRaceStarted;
    }

    private void OnRaceStarted()
    {
        if (!carInputs.GetCarPilot())
        {
            drivetrain.ChangeGear(2);
        }
    }


    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
            if (!drivetrain.externalController) drivetrain.externalController = true;
        }
        else
        {
            if (drivetrain.externalController && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3)) drivetrain.externalController = false;
            if (carAI.NavigateTWaypoints.GoPits)
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                {
                    //No way to limit the car speed on RCC
                }
            if (carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
                PlayerController();
            if (IRDSStatistics.GetCanRace())
            {
                drivetrain.externalController = true;
            }
            else
            {
                drivetrain.externalController = false;
            }
        }
    }

    void carController()
    {
        drivetrain.steerInput = carInputs.GetSteerInput();
        drivetrain.handbrakeInput = carInputs.GetHandBrakeInput();

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {
            if (carInputs.targetGearExtarnelPhysics == 0)
            {
                drivetrain.throttleInput = -carInputs.GetThrottleInput();
            }
            else
            {
                drivetrain.throttleInput = carInputs.GetThrottleInput();

            }
            drivetrain.brakeInput = carInputs.GetBrakeInput();
        }
        else
        {
            drivetrain.throttleInput = 0;
            drivetrain.brakeInput = 1;
            drivetrain.GearShiftTo(1);
        }

    }

    void PlayerController()
    {

        if (carInputs.auto3)
            drivetrain.throttleInput = carInputs.GetThrottleInput();
        else
        {

            if (Input.GetKey(KeyCode.UpArrow))
                drivetrain.throttleInput += 0.05f;
            drivetrain.throttleInput = Mathf.Clamp01(drivetrain.throttleInput);
        }
        if (carInputs.auto1)
            drivetrain.brakeInput = carInputs.GetBrakeInput();
        else
        {

            if (Input.GetKey(KeyCode.DownArrow))
                drivetrain.brakeInput += 0.05f;
            drivetrain.brakeInput = Mathf.Clamp01(drivetrain.brakeInput);
        }

        if (carInputs.auto2)
            drivetrain.steerInput = carInputs.GetSteerInput();
        else
        {

            drivetrain.steerInput = Mathf.Clamp(Input.GetAxis("Horizontal"), -1, 1);
        }

        drivetrain.handbrakeInput = carInputs.GetHandBrakeInput();
    }


    //end line
}