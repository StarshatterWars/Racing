using UnityEngine;

public class IRDSCarControllInputRandomation : MonoBehaviour
{

    // cached reference for CarControl
    public VehicleParent drivetrain;
    public BasicInput playerInput;
    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<VehicleParent>();
        if (playerInput == null)
            playerInput = GetComponent<BasicInput>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        //		airDrag = drivetrain.maxSpeed;
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
    }
    void Start()
    {
        if (playerInput != null)
        {
            if (carInputs.GetCarPilot() && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                playerInput.enabled = true;
            }
            else playerInput.enabled = false;
        }

        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];

    }


    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
            if (playerInput != null && playerInput.enabled) playerInput.enabled = false;
        }
        else
        {
            if (playerInput != null && playerInput.enabled == false && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3)) playerInput.enabled = true;
            //			if (carInputs.GetGoPits())
            //				if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
            //				{
            //					drivetrain.maxSpeed =IRDSWPManager.GetPitMaxSpeed();
            //				}
            if (carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
                PlayerController();
        }
    }

    void carController()
    {

        drivetrain.SetSteer(carInputs.GetSteerInput());
        drivetrain.SetEbrake(carInputs.GetHandBrakeInput());

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {
            if (carInputs.targetGearExtarnelPhysics - 1 < 1)
            {
                drivetrain.SetBrake(carInputs.GetThrottleInput());
            }
            else
            {
                drivetrain.SetAccel(carInputs.GetThrottleInput());

            }
            drivetrain.SetBrake(carInputs.GetBrakeInput());
        }
        else
        {
            drivetrain.SetAccel(0);
            drivetrain.SetEbrake(1);
            drivetrain.SetBrake(0);
        }

    }

    void PlayerController()
    {
        if (!IRDSStatistics.GetCanRace() && !carAI.rollingStart)
        {
            playerInput.enabled = false;
            drivetrain.SetEbrake(1);
            drivetrain.SetAccel(0);
            drivetrain.SetBrake(0);
        }
        else if (!playerInput.enabled) playerInput.enabled = true;

        if (carInputs.auto3)
            drivetrain.SetAccel(carInputs.GetThrottleInput());
        if (carInputs.auto1)
            drivetrain.SetBrake(carInputs.GetBrakeInput());
        if (carInputs.auto2)
            drivetrain.SetSteer(carInputs.GetSteerInput());
    }


    //end line
}