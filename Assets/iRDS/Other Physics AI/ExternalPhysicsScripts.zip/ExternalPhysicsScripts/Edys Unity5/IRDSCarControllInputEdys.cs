using UnityEngine;
using EVP;

public class IRDSCarControllInputEdys : MonoBehaviour
{

    // cached reference for CarControl
    public VehicleController drivetrain;
    public VehicleStandardInput playerInput;
    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    private float airDrag;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<VehicleController>();
        if (playerInput == null)
            playerInput = GetComponent<VehicleStandardInput>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        //		airDrag = drivetrain.maxSpeed;
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
    }
    void Start()
    {
        if (playerInput != null)
        {
            if (carInputs.GetCarPilot() && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                playerInput.enabled = true;
            }
            else playerInput.enabled = false;
        }

        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];

    }


    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
            if (playerInput != null && playerInput.enabled == true) { playerInput.enabled = false; }
        }
        else
        {
            if (playerInput != null && playerInput.enabled == false && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                playerInput.enabled = true;
            }

            if (carAI.NavigateTWaypoints.GoPits)
            {
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                {
                    drivetrain.maxSpeedForward = IRDSWPManager.GetPitMaxSpeed();
                }
            }

            if (carInputs.auto1 || carInputs.auto2 || carInputs.auto3)
            {
                PlayerController();
            }
        }
    }

    void carController()
    {

        drivetrain.steerInput = carInputs.GetSteerInput();
        drivetrain.handbrakeInput = carInputs.GetHandBrakeInput();

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {
            if (carInputs.targetGearExtarnelPhysics - 1 < 1)
            {
                drivetrain.throttleInput = -carInputs.GetThrottleInput();
            }
            else
            {
                drivetrain.throttleInput = carInputs.GetThrottleInput();

            }
            drivetrain.brakeInput = carInputs.GetBrakeInput();
        }
        else
        {
            drivetrain.throttleInput = 0;
            drivetrain.brakeInput = 1;
        }

    }

    void PlayerController()
    {

        if (carInputs.auto3)
            drivetrain.throttleInput = carInputs.GetThrottleInput();
        else
        {

            if (Input.GetKey(KeyCode.UpArrow))
                drivetrain.throttleInput += 0.05f;
            drivetrain.throttleInput = Mathf.Clamp01(drivetrain.throttleInput);
        }
        if (carInputs.auto1)
            drivetrain.brakeInput = carInputs.GetBrakeInput();
        else
        {

            if (Input.GetKey(KeyCode.DownArrow))
                drivetrain.brakeInput += 0.05f;
            drivetrain.brakeInput = Mathf.Clamp01(drivetrain.brakeInput);
        }

        if (carInputs.auto2)
            drivetrain.steerInput = carInputs.GetSteerInput();
        else
        {

            drivetrain.steerInput = Mathf.Clamp(Input.GetAxis("Horizontal"), -1, 1);
            //			drivetrain.steerInput=Mathf.Clamp(drivetrain.steerInput,-1,1);
        }
        drivetrain.handbrakeInput = carInputs.GetHandBrakeInput();

        //		drivetrain.gearInput = carInputs.GetGearInput();
    }


    //end line
}