using UnityEngine;
using VehiclePhysics;

public class IRDSCarControllInputEdys : MonoBehaviour
{

    // cached reference for CarControl
    public VPVehicleController drivetrain;
    public VPStandardInput playerInput;
    public IRDSCarControllInput carInputs;
    public IRDSCarControllerAI carAI;
    private float airDrag;
    public Transform[] frontWheels;

    public float[] kfriction = { 1, 1 };
    // Initialize
    void Awake()
    {
        if (drivetrain == null)
            drivetrain = GetComponent<VPVehicleController>();
        if (playerInput == null)
            playerInput = GetComponent<VPStandardInput>();
        if (carInputs == null)
            carInputs = GetComponent<IRDSCarControllInput>();
        if (carAI == null)
            carAI = GetComponent<IRDSCarControllerAI>();
        //		airDrag = drivetrain.maxSpeed;
        carAI.SetFrictionExtaernalPhysics(kfriction);
        carInputs.SetTopSpeedExternalPhysics(150f);
        carAI.SetHFactorExternalPhysics(0.2f);
        carAI.SetClFactorExternalPhysics(0.3f);
        carAI.SetWingaFactorExternalPhysics(1f);
    }
    void Start()
    {
        if (playerInput != null)
        {
            if (carInputs.GetCarPilot() && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                playerInput.enabled = true;
            }
            else playerInput.enabled = false;
        }

        carAI.SetIRDSWheelsCenter(frontWheels);
        carAI.SetMaxSteerLockExternalPhysics(28);
        carInputs.gearRatiosLengthExternalPhysics = 3;
        carInputs.maxRpmExternalPhysics = 1000;
        carInputs.gearSpeedsExternalCarPhysics = new float[3];

    }


    void FixedUpdate()
    {
        if (!carInputs.GetCarPilot())
        {
            carController();
            if (playerInput != null && playerInput.enabled == true) { playerInput.enabled = false; }
        }
        else
        {
            if (playerInput != null && playerInput.enabled == false && (!carInputs.auto1 && !carInputs.auto2 && !carInputs.auto3))
            {
                playerInput.enabled = true;
            }

            if (carAI.NavigateTWaypoints.GoPits)
            {
                if (carInputs.GetCarSpeed() > IRDSWPManager.GetPitMaxSpeed())
                {
                    drivetrain.speedControl.speedLimit = IRDSWPManager.GetPitMaxSpeed();
                }
            }
            else
            {
                drivetrain.speedControl.speedLimit = 10000;
            }
        }
    }

    void carController()
    {
        drivetrain.data.Set(Channel.Input, InputData.Steer, (int)(carInputs.GetSteerInput() * 10000));
        drivetrain.data.Set(Channel.Input, InputData.Handbrake, (int)(carInputs.GetHandBrakeInput() * 10000));

        if (IRDSStatistics.GetCanRace() || carAI.rollingStart)
        {
            if (carInputs.targetGearExtarnelPhysics - 1 < 1)
            {
                drivetrain.data.Set(Channel.Input, InputData.Throttle, (int)(-carInputs.GetThrottleInput() * 10000));
            }
            else
            {
                drivetrain.data.Set(Channel.Input, InputData.Throttle, (int)(carInputs.GetThrottleInput() * 10000));
            }
            drivetrain.data.Set(Channel.Input, InputData.Brake, (int)(carInputs.GetBrakeInput() * 10000));
        }
        else
        {
            drivetrain.data.Set(Channel.Input, InputData.Throttle, 0);
            drivetrain.data.Set(Channel.Input, InputData.Brake, 10000);
        }

    }
    //end line
}